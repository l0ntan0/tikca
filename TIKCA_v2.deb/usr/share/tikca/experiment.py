import datetime
from dateutil.tz import tzutc


event = 1476789279

print(datetime.datetime.now(tz=tzutc()))
STOPDATE = datetime.datetime.fromtimestamp(event, tz=tzutc())
print(STOPDATE)

if datetime.datetime.now(tz=tzutc()) > STOPDATE:
    print("bin drüber")