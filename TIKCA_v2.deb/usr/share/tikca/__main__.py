#!/usr/bin/env python
# -*- coding: utf-8 -*-
'''
    tikca
    ~~~~~~~~~~~~~~~~~~~~

    :copyright: 2016, Pascal Zurek <pascal.zurek@tik.uni-stuttgart.de>
    :license: LGPL – see license.lgpl for more details.
'''

from tikca import tikca

if __name__ == '__main__':

    cfg = '/etc/pyca.conf'
    tikca.run()